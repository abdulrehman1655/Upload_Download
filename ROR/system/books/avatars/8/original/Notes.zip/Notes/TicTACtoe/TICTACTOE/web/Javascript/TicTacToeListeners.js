$(document).ready(function(){              
         $('body').ready(function(){
                // $("#but").hide();     
                 getName();  
         });
         $('#one_box').click(function(){
                  check_status("one","one_box") ;       
         });
         $('#two_box').click(function(){
                  check_status("two","two_box") ;       
         });
         $('#three_box').click(function(){
                  check_status("three","three_box") ;       
         });
         $('#four_box').click(function(){
                  check_status("four","four_box") ;       
         });
         $('#five_box').click(function(){
                  check_status("five","five_box") ;       
         });
         $('#six_box').click(function(){
                  check_status("six","six_box") ;       
         });
         $('#seven_box').click(function(){
                  check_status("seven","seven_box") ;       
         });
         $('#eight_box').click(function(){
                  check_status("eight","eight_box") ;       
         });
         $('#nine_box').click(function(){
                  check_status("nine","nine_box") ;       
         });
         $('#but').click(function(){
                  playAgain();       
         });
         
});  