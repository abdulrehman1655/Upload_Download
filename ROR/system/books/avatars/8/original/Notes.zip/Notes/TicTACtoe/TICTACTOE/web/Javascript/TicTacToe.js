turn_count=0;
name1;
name2;
turn;

function getName()   //for turn
   {
       name1=prompt("Enter First Player Name","");
       name2=prompt("Enter Second Player Name","");
       turn=Math.floor(Math.random() * (1 - 0 + 1)) + 0;
       if(turn==0)
         {
           alert(name1+" will take first"+ " symbol is 0");
           turn_control=0;
         }       
        else
         {
            alert(name2+" will take first"+ " symbol is 1");
            turn_control=1;
         }
    }  
function check_status(i,box)   //to display click 
    {        
       win_lose_call_control=0;
       if(turn_control==0)
       {
          if(parseInt(document.getElementById(i).value)==2)
             {
                 document.getElementById(i).value=0;
                 win_lose_call_control=1;
                 turn_control=1;
                 document.getElementById(box).src="images/zero";
                 
              }
           else
              {
                 alert("Already Occupied");
              }
         }
         else
         {
             if(parseInt(document.getElementById(i).value)==2)
               {
                   document.getElementById(i).value=1;
                   win_lose_call_control=1;
                   turn_control=0;
                   document.getElementById(box).src="images/cross";
                }
              else
                {
                    alert("Already Occupied");
                 }              
          }     
          if(win_lose_call_control==1)
            {   
               win_lose_draw();
            }
   }
function win_lose_draw()      // to decide who wins
     {
        turn_count++;
        var turns=new Array();
        turns[1]=document.getElementById("one").value;
        turns[2]=document.getElementById("two").value;
        turns[3]=document.getElementById("three").value;
        turns[4]=document.getElementById("four").value;
        turns[5]=document.getElementById("five").value;
        turns[6]=document.getElementById("six").value;
        turns[7]=document.getElementById("seven").value;
        turns[8]=document.getElementById("eight").value;
        turns[9]=document.getElementById("nine").value;   
        
       win_draw_decision=0;    
            
            //for player 0 turn
            if(turns[1]==0&&turns[2]==0&&turns[3]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            else if(turns[4]==0&&turns[5]==0&&turns[6]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            else if(turns[7]==0&&turns[8]==0&&turns[9]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            else if(turns[1]==0&&turns[4]==0&&turns[7]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            else if(turns[2]==0&&turns[5]==0&&turns[8]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            else if(turns[3]==0&&turns[6]==0&&turns[9]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            else if(turns[1]==0&&turns[5]==0&&turns[9]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            else if(turns[3]==0&&turns[5]==0&&turns[7]==0)
                {
                  wins(name1);
                  win_draw_decision=1;
                  reset(0);
                }
            
            //for player 1 turn 
            
            if(turns[1]==1&&turns[2]==1&&turns[3]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            else if(turns[4]==1&&turns[5]==1&&turns[6]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            else if(turns[7]==1&&turns[8]==1&&turns[9]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            else if(turns[1]==1&&turns[4]==1&&turns[7]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            else if(turns[2]==1&&turns[5]==1&&turns[8]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            else if(turns[3]==1&&turns[6]==1&&turns[9]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            else if(turns[1]==1&&turns[5]==1&&turns[9]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            else if(turns[3]==1&&turns[5]==1&&turns[7]==1)
                {
                  wins(name2);
                  win_draw_decision=1;
                  reset(1);
                }
            
            if(turn_count==9&&win_draw_decision==0)
                {
                     $("#but").show();
                  wins("Match Draw");
                  reset(5);
                 
                  
                }      
    }
            
function wins(name_of_winner)   //display winner name ajax
        
      {
           var xmlhttp;
           if (window.XMLHttpRequest)
             {// code for IE7+, Firefox, Chrome, Opera, Safari
                 xmlhttp=new XMLHttpRequest();
             }
             else
             {// code for IE6, IE5
                  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
              }
              xmlhttp.onreadystatechange=function()
                {
                   if (xmlhttp.readyState==4 && xmlhttp.status==200)
                     {
                         document.getElementById("myDiv").innerHTML=xmlhttp.responseText;
                        
                     }
                 }
           
                 xmlhttp.open("GET","ajax.jsp?player="+name_of_winner,true);
                 xmlhttp.send();
                
                 
       }
function playAgain(){  //restart game
     window.location="http://localhost:8080/TICTACTOE/";
}
function reset (reset_value){
    
    }


    