     
        $(document).ready(function(){
            $("#arrow_top").hide();
            
        });
       
        $(window).scroll(function () {

               $("#arrow_top").hide();
               
               if(scrollY>500)
               {
                 $("#arrow_top").show();
               }
 });     

        function flip(){
            $("#flip").fadeIn(500).slideDown(10000);
        }
        function flop(){
            $("#flip").fadeOut(1000).slideUp(300);
        }
        function jump(){
           
            $("html, body").animate({ scrollTop: $(document).height()-2000 }, 2500);
            
            //window.scrollTo(1000000,1000000);
           // id=setInterval(function(){window.scrollTo(1000,2500);},10000);
            //clearInterval(id);
         /*   
            window.scrollTo(1000,1600);
            id=setInterval(function(){window.scrollTo(1000,1400);},10000);
            clearInterval(id);
            
            window.scrollTo(1000,1200);
            id=setInterval(function(){window.scrollTo(1000,1000);},10000);
            clearInterval(id);
            
            window.scrollTo(1000,800);
            id=setInterval(function(){window.scrollTo(1000,700);},10000);
            clearInterval(id);
            
            window.scrollTo(1000,600);
            id=setInterval(function(){window.scrollTo(0,500);},10000);
            clearInterval(id);
            
            window.scrollTo(1000,400);
            id=setInterval(function(){window.scrollTo(0,300);},10000);
            clearInterval(id);
            
            window.scrollTo(1000,200);
            id=setInterval(function(){window.scrollTo(0,100);},10000);
            clearInterval(id);
            
            window.scrollTo(1000,50);
            id=setInterval(function(){window.scrollTo(0,0);},10000);
            clearInterval(id);*/
        }
        
   