i = 0;
function show_hide()//for client testimonials fading effect
{

    if (i == 0)
    {
        $(".fade").fadeOut(5);
        $(".fade1").fadeIn(4000);
        i = 1;
    }
    else
    {
        $(".fade1").fadeOut(5);
        $(".fade").fadeIn(4000);
        i = 0;
    }
}

function helloTimer()
{
    $(".fade1").fadeOut();
    $(".fade").fadeIn(4000);
    $("#slider").hide();

    setInterval(function() {
        show_hide();
    }, 10000);
}

function display_arrow_back() {

    $("#prev").show();
}
function disply_none() {
    $("#prev").hide();
}
function display_next(){
    $("#next").show();
}
function display_none_next(){
    $("#next").hide();
}
            